﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using Xbim.COBieLiteUK;

namespace Xbim.Client
{
    public class COBieLiteWorkerToIfc : ICOBieLiteWorker
    {
        public BackgroundWorker Worker
        { get; set;}

        public COBieLiteWorkerToIfc()
        {
            Worker = new BackgroundWorker();
            Worker.WorkerReportsProgress = true;
            Worker.WorkerSupportsCancellation = false;
            Worker.DoWork += CobieLiteUKWorker;
        }

        public void Run(Params args)
        {
            Worker.RunWorkerAsync(args);
        }

        private void CobieLiteUKWorker(object sender, DoWorkEventArgs e)
        {
            Params parameters = e.Argument as Params;
            if ((string.IsNullOrEmpty(parameters.ModelFile)) || (!File.Exists(parameters.ModelFile)))
            {
                Worker.ReportProgress(0, string.Format("That file doesn't exist: {0}.", parameters.ModelFile));
                return;
            }
            e.Result = GenerateCOBieIfcFile(parameters); //returns the ifc file name
        }

        private string GenerateCOBieIfcFile(Params parameters)
        {
            string ifcName = Path.ChangeExtension(parameters.ModelFile, ".ifc");
            string msg;
            var facility = Facility.ReadCobie(parameters.ModelFile, out msg, parameters.TemplateFile);
            
            return ifcName;
        }
    }
}
